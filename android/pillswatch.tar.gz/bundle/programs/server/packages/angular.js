(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var LocalCollection = Package.minimongo.LocalCollection;
var Minimongo = Package.minimongo.Minimongo;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package.angular = {};

})();

//# sourceMappingURL=angular.js.map
