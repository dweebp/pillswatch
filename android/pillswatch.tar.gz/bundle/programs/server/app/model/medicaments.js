(function(){Medicaments = new Mongo.Collection('medicaments');

})();
