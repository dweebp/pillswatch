(function(){HealthTopics = new Mongo.Collection('healthTopics');

})();
