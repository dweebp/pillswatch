(function(){Meteor.startup(function () {
    if (Medicaments.find().count() === 0) {

    }
});

})();
